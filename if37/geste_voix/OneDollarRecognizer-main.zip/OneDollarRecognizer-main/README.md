# OneDollarRecognizer

OneDollarRecognizer  est un agent codé en [Processing](https://www.processing.org) permettant de reconnaître un ensemble de gestes unistrokes appris au préalable (et stockés). Ce code implémente l'algorithme du $1 Recognizer (http://faculty.washington.edu/wobbrock/pubs/uist-07.01.pdf)

OneDollarRecognizer permet aussi d'envoyer le résultat de sa reconnaissance sur le [bus ivy](https://github.com/truillet/ivy).
